from django.test import TestCase
from django.urls import reverse
from django.test import TestCase
from .models import Intent, Response


class BasicViewTests(TestCase):
    def test_index_status_code(self):
        response = self.client.get(reverse('chat:index'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Chatbot Skeleton')


class IntentResponseTest(TestCase):
    def setUp(self):
        self.intent = Intent.objects.create(name="test", description="Test intent")
        self.response = Response.objects.create(intent=self.intent, text="Test response")

    def test_intent_response_relation(self):
        self.assertEqual(self.response.intent.name, "test")


from django.test import TestCase
from django.urls import reverse

class ChatViewTest(TestCase):
    def test_index_status_code(self):
        response = self.client.get(reverse('chat:index'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Chatbot Skeleton')

    def test_send_message_ajax(self):
        # Set a session_id cookie to avoid NOT NULL error
        self.client.cookies['session_id'] = 'test-session-123'
        response = self.client.post(reverse('chat:send_message'), {'message':'hello'}, HTTP_X_REQUESTED_WITH='XMLHttpRequest')
        self.assertEqual(response.status_code, 200)
        self.assertIn('reply', response.json())
