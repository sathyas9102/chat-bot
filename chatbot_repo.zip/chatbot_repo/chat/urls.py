from django.urls import path
from . import views

app_name = 'chat'

urlpatterns = [
    path('chat/', views.index, name='index'),
    path('chat/send/', views.send_message, name='send_message'),  # new AJAX endpoint
    path("chatbot/", views.chatbot_reply, name="chatbot_reply"),

]
