import os, json, random
from difflib import get_close_matches
from .models import BotSetting

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INTENTS_FILE = os.path.join(BASE_DIR, "intents.json")

with open(INTENTS_FILE, "r", encoding="utf-8") as f:
    INTENTS = json.load(f)["intents"]

def get_bot_response(user_input):
    user_input_lower = user_input.lower().strip()

    # Check all intents first
    for intent in INTENTS:
        patterns = [p.lower() for p in intent.get("patterns", [])]
        # exact match
        if user_input_lower in patterns:
            return random.choice(intent["responses"])
        # fuzzy match
        match = get_close_matches(user_input_lower, patterns, n=1, cutoff=0.6)
        if match:
            return random.choice(intent["responses"])

    # fallback to bot setting
    bot_setting = BotSetting.objects.first()
    if bot_setting and bot_setting.default_response:
        return bot_setting.default_response
    return "Hmm, I’m not sure I got that 😅 Could you say it again?"
