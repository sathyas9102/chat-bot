from django.db import models

# Placeholder models for Step 1 - will expand in STEP 2
class Placeholder(models.Model):
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Placeholder"
        verbose_name_plural = "Placeholders"

    def __str__(self):
        return f"Placeholder {self.pk}"

from django.db import models

class Intent(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name

    def response_patterns(self):
        """
        Return all regex patterns from linked responses for matching.
        Each Response stores patterns as comma-separated regex.
        """
        patterns = []
        for resp in self.responses.all():
            if resp.patterns:
                patterns.extend([p.strip() for p in resp.patterns.split(',')])

        return patterns


class Response(models.Model):
    intent = models.ForeignKey(Intent, related_name='responses', on_delete=models.CASCADE)
    patterns = models.TextField(blank=True, help_text="Comma-separated regex patterns")
    reply_text = models.TextField(blank=True)  # add this line

    def __str__(self):
        return f"Response for {self.intent.name}"
    
class Conversation(models.Model):
    session_id = models.CharField(max_length=100, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)  # <- required
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.session_id

class Message(models.Model):
    conversation = models.ForeignKey(Conversation, on_delete=models.CASCADE, related_name='messages')
    sender = models.CharField(max_length=10, choices=(('user','User'),('bot','Bot')))
    text = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.sender}: {self.text[:30]}"

class BotSetting(models.Model):
    default_response = models.TextField(default="Sorry, I did not understand.")
    active = models.BooleanField(default=True)
    
    def __str__(self):
        return "Bot Settings"
