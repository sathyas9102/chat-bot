from django.shortcuts import render
from django.http import JsonResponse
from .models import Conversation, Message, BotSetting, Intent, Response
import uuid
import random
from difflib import get_close_matches



def send_message(request):
    if request.method == 'POST':
        text = request.POST.get('message', '').strip()
        if not text:
            return JsonResponse({'error': 'Empty message'}, status=400)

        # Ensure session_id
        session_id = request.COOKIES.get('session_id') or str(uuid.uuid4())
        conversation, _ = Conversation.objects.get_or_create(session_id=session_id)

        # Save user message
        Message.objects.create(conversation=conversation, sender='user', text=text)

        # --- Improved fuzzy matching ---
        bot_reply = None
        intents = Intent.objects.all()
        text_lower = text.lower()

        for intent in intents:
            patterns = [p.lower() for p in intent.response_patterns()]
            # Use difflib to find closest match
            match = get_close_matches(text_lower, patterns, n=1, cutoff=0.5)  # 0.5 for moderate similarity
            if match:
                responses = list(intent.responses.all().values_list('text', flat=True))
                if responses:
                    bot_reply = random.choice(responses)
                    break

        # Fallback
        if not bot_reply:
            bot_setting = BotSetting.objects.first()
            bot_reply = bot_setting.default_response if bot_setting else "Sorry, I did not understand."

        # Save bot message
        Message.objects.create(conversation=conversation, sender='bot', text=bot_reply)

        return JsonResponse({'reply': bot_reply})

    return JsonResponse({'error': 'Invalid request'}, status=400)


from django.shortcuts import render
from django.http import JsonResponse
from .models import Conversation, Message
import uuid
from .chatbot import get_bot_response

def index(request):
    session_id = request.COOKIES.get('session_id')
    if not session_id:
        session_id = str(uuid.uuid4())

    conversation, _ = Conversation.objects.get_or_create(session_id=session_id)
    messages = conversation.messages.all().order_by('timestamp')

    response = render(request, 'chat/index.html', {'messages': messages})
    response.set_cookie('session_id', session_id)
    return response


def chatbot_reply(request):
    if request.method == "POST":
        user_message = request.POST.get("message", "").strip()
        if not user_message:
            return JsonResponse({"reply": "Please type something."})

        session_id = request.COOKIES.get('session_id') or str(uuid.uuid4())
        conversation, _ = Conversation.objects.get_or_create(session_id=session_id)

        # Save user message
        Message.objects.create(conversation=conversation, sender='user', text=user_message)

        # Get bot reply (all logic handled inside chatbot.py)
        bot_reply = get_bot_response(user_message)

        # Save bot message
        Message.objects.create(conversation=conversation, sender='bot', text=bot_reply)

        return JsonResponse({"reply": bot_reply})

    return JsonResponse({"error": "Invalid request"}, status=400)