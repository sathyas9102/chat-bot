from django.contrib import admin
from .models import Placeholder

@admin.register(Placeholder)
class PlaceholderAdmin(admin.ModelAdmin):
    list_display = ('id', 'created')

from django.contrib import admin
from .models import Intent, Response, Conversation, Message, BotSetting

@admin.register(Intent)
class IntentAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')

@admin.register(Response)
class ResponseAdmin(admin.ModelAdmin):
    list_display = ('intent', 'reply_text', 'patterns') 

@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    list_display = ('session_id', 'created_at')  # Make sure 'created_at' exists in model
    readonly_fields = ('session_id', 'created_at')

@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ('conversation', 'sender', 'text', 'timestamp')
    list_filter = ('sender',)
    search_fields = ('text',)

@admin.register(BotSetting)
class BotSettingAdmin(admin.ModelAdmin):
    list_display = ('default_response',)
