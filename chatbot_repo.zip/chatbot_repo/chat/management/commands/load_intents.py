from django.core.management.base import BaseCommand
from chat.models import Intent, Response
import json

class Command(BaseCommand):
    help = "Load intents from a JSON file"

    def add_arguments(self, parser):
        parser.add_argument("file_path", type=str, help="Path to the intents JSON file")

    def handle(self, *args, **kwargs):
        file_path = kwargs["file_path"]

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            self.stderr.write(self.style.ERROR(f"Failed to open {file_path}: {e}"))
            return

        # Some files use "intents", some use "data"
        intents = data.get("intents") or data.get("data")
        if not intents:
            self.stderr.write(self.style.ERROR("No 'intents' or 'data' key found in JSON"))
            return

        for item in intents:
            tag = item.get("tag") or item.get("intent")
            if not tag:
                continue

            patterns = item.get("patterns", [])
            responses = item.get("responses", [])

            intent, _ = Intent.objects.get_or_create(name=tag)
            intent.patterns = patterns
            intent.save()

            # Clear old responses to avoid duplicates
            intent.responses.all().delete()

            for resp in responses:
                Response.objects.create(intent=intent, text=resp)

        self.stdout.write(self.style.SUCCESS("Intents loaded successfully!"))
